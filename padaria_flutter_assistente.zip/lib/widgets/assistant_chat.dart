import 'package:flutter/material.dart';
import '../services/finance_service.dart';

class AssistantChatWidget extends StatelessWidget {
  final FinanceService financeService;

  const AssistantChatWidget({super.key, required this.financeService});

  @override
  Widget build(BuildContext context) {
    final resumo = financeService.gerarResumo();
    return Container(
      width: double.infinity,
      color: Colors.brown.shade100,
      padding: const EdgeInsets.all(16),
      child: Text(
        'Oi Seu Jorge! Aqui está o resumo financeiro da padaria:\n\n$resumo',
        style: const TextStyle(fontSize: 16),
      ),
    );
  }
}