class FinanceService {
  final List<Map<String, dynamic>> _entradas = [];
  final List<Map<String, dynamic>> _saidas = [];

  void adicionarEntrada(double valor, String descricao) {
    _entradas.add({'valor': valor, 'descricao': descricao});
  }

  void adicionarSaida(double valor, String descricao) {
    _saidas.add({'valor': valor, 'descricao': descricao});
  }

  double calcularLucroMensal() {
    final totalEntradas = _entradas.fold(0.0, (soma, item) => soma + item['valor']);
    final totalSaidas = _saidas.fold(0.0, (soma, item) => soma + item['valor']);
    return totalEntradas - totalSaidas;
  }

  String gerarResumo() {
    return 'Total de Entradas: R\$ ${_entradas.fold(0.0, (s, e) => s + e['valor']).toStringAsFixed(2)}\n'
        'Total de Saídas: R\$ ${_saidas.fold(0.0, (s, e) => s + e['valor']).toStringAsFixed(2)}\n'
        'Lucro do Mês: R\$ ${calcularLucroMensal().toStringAsFixed(2)}';
  }
}