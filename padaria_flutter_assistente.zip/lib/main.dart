import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const PadariaApp());
}

class PadariaApp extends StatelessWidget {
  const PadariaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Assistente da Padaria',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.brown),
      home: const HomeScreen(),
    );
  }
}