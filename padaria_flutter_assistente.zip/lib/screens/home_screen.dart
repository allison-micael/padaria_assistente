import 'package:flutter/material.dart';
import '../services/finance_service.dart';
import '../widgets/assistant_chat.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final FinanceService _financeService = FinanceService();

  final TextEditingController _valorController = TextEditingController();
  final TextEditingController _descricaoController = TextEditingController();
  String _tipo = 'Entrada';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Assistente da Padaria Nova Esperança')),
      body: Column(
        children: [
          AssistantChatWidget(financeService: _financeService),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  controller: _valorController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Valor'),
                ),
                TextField(
                  controller: _descricaoController,
                  decoration: const InputDecoration(labelText: 'Descrição'),
                ),
                DropdownButton<String>(
                  value: _tipo,
                  items: ['Entrada', 'Saída'].map((tipo) {
                    return DropdownMenuItem(value: tipo, child: Text(tipo));
                  }).toList(),
                  onChanged: (value) => setState(() => _tipo = value!),
                ),
                ElevatedButton(
                  onPressed: () {
                    final valor = double.tryParse(_valorController.text) ?? 0.0;
                    final desc = _descricaoController.text;
                    if (_tipo == 'Entrada') {
                      _financeService.adicionarEntrada(valor, desc);
                    } else {
                      _financeService.adicionarSaida(valor, desc);
                    }
                    _valorController.clear();
                    _descricaoController.clear();
                    setState(() {});
                  },
                  child: const Text('Registrar'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}